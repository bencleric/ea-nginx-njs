
/*
 * Copyright (C) Igor Sysoev
 * Copyright (C) NGINX, Inc.
 */

#ifndef _NJS_BOOLEAN_H_INCLUDED_
#define _NJS_BOOLEAN_H_INCLUDED_


extern const njs_object_type_init_t  njs_boolean_type_init;


#endif /* _NJS_BOOLEAN_H_INCLUDED_ */
