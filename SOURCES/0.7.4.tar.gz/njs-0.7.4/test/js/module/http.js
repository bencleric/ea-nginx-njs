var http = {};

http.check = function() {
    return jwt.verify();
}

export default http;
